<?php
    include_once("conexaobd/ConexaoBD.php");
    session_start();
if(!isset($_SESSION['id'])){
    header("Location: Inicio.php");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quartos - Hotel</title>
    <link rel="stylesheet" href="Principal.css">
    <link rel="icon" href="imagens/logo-pousada-quinta-do-ypua-vmake.png" type="image/jpeg">
</head>

<style>
    .navbar ul.active {
    transform: translateX(0); /* Move o menu para a posição visível */
    height: 117vh; /* Faz o menu ocupar toda a altura da tela */
}
</style>
<body>
    <div class="navbar">
        <div class="navbar-content">
            <button style="background: none" class="menu-btn">☰</button>
            <ul class="menu">
            <li><a href="Principal.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-house" viewBox="0 0 16 16">
                            <path
                                d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293zM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5z" />
                                </svg> Home</a></li>

                <li><a href="Perfil.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                            <path fill-rule="evenodd"
                                d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1" />
                        </svg> Meu Perfil</a></li>

                <li><a href="OpcoesQuarto.php"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" width="16" height="16"
                            class="fas fa-bed" style="color: #ffffff;">
                            <path fill="#ffffff" d="M176 256c44.1 0 80-35.9 80-80s-35.9-80-80-80-80 35.9-80 80 35.9 80 80 80zm352-128H304c-8.8 0-16 7.2-16 16v144H64V80c0-8.8-7.2-16-16-16H16C7.2 64 0 71.2 0 80v352c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16v-48h512v48c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V240c0-61.9-50.1-112-112-112z"/>
                        </svg> Opções de Quartos</a></li>

                <li><a href="Reservas.php"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="16" height="16"
                            class="fa-regular fa-clock" style="color: #ffffff;">
                            <path fill="#ffffff" d="M464 256A208 208 0 1 1 48 256a208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0A256 256 0 1 0 0 256zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"/>
                        </svg> Reservas</a></li>

                        <li><a href="HistoricoReservas.php"> <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-card-list" viewBox="0 0 16 16">
                        <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2z"/>
                        <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8m0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0M4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0"/>
                        </svg> Minhas Reservas</a></li>

                        <li><a href="todasReservas.php"> <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="currentColor" class="bi bi-card-list" viewBox="0 0 16 16">
                        <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2z"/>
                        <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8m0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0M4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0"/>
                        </svg> Histórico - Reservas</a></li>

                <li><a href="Sair.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0z" />
                            <path fill-rule="evenodd"
                                d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z" />
                        </svg> Sair</a></li>
            </ul>
            <div class="logo">
                <img src="imagens/logo-pousada-quinta-do-ypua-vmake.png" alt="Logo do Hotel">
            </div>
            <div class="boasvindas">
                
            </div>
        </div>
    </div>
    <div class="background"></div>
    <div class="rooms-section">
        <h2>Opções de Quartos</h2>
        <div class="rooms-container">
            <!-- Quartos já adicionados -->
            <div class="room">
                <img src="imagens/quarto_domo.jpeg" alt="Quarto Domo">
                <div class="room-details">
                    <h3>Quarto Domo</h3>
                    <p>O Domo é a grande novidade da pousada. Uma acomodação totalmente diferenciada construída nos padrões arquitetônicos dos domos geodésicos modernos.</p>
                    <p class="price">R$ 590/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
            <div class="room">
                <img src="imagens/quarto_charrua.jpeg" alt="Quarto Charrua">
                <div class="room-details">
                    <h3>Quarto Charrua (Bus)</h3>
                    <p>O Charrua é uma das grandes novidades da pousada. Veja alguns detalhes que acompanham esta acomodação especial: Banheira de hidromassagem, cozinha básica, etc.</p>
                    <p class="price">R$ 490/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
            <div class="room">
                <img src="imagens/quarto_suitecozinha.jpg" alt="Suíte com Cozinha">
                <div class="room-details">
                    <h3>Suíte com Cozinha</h3>
                    <p>Com ampla vista para o mar, esta acomodação possui cama de casal, cama extra, ar-condicionado e TV, possui também uma cozinha com utensílios básicos e banheiro.</p>
                    <p class="price">R$ 390/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
            <div class="room">
                <img src="imagens/quarto_chale.jpg" alt="Chalé Família">
                <div class="room-details">
                    <h3>Chalé Família</h3>
                    <p>Esta acomodação possui dois quartos, um dos quartos com cama de casal e TV e o outro com cama de casal e uma de solteiro. Ambos os quartos tem ar-condicionado.</p>
                    <p class="price">R$ 590/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
            <div class="room">
                <img src="imagens/quarto_cabana.jpg" alt="Cabana">
                <div class="room-details">
                    <h3>Cabana</h3>
                    <p> Esta acomodação fica em uma área mais reservada da pousada. Possui cama de casal, uma cama de solteiro, cama extra, ar-condicionado, TV, cozinha básica e banheiro.</p>
                    <p class="price">R$ 490/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
            <div class="room">
                <img src="imagens/estacionamento.jpg" alt="Estacionamento para Overlanders">
                <div class="room-details">
                    <h3>Estacionamento para Overlanders</h3>
                    <p>A pousada tem um espaço plano com vista para o mar, destinado a estacionamento de overlanders, tendo disponível para uso ponto de água e luz.</p>
                    <p class="price">R$ 280/noite</p>
                    <a href="Reservas.php" class="book-btn">Reservar</a>
                </div>
            </div>
    </div>
    <script src="scriptmenu.js"></script>
</body>
</html>
