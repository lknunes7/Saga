document.querySelector('.menu-btn').addEventListener('click', function() {
    document.querySelector('.navbar ul').classList.toggle('active');
    })